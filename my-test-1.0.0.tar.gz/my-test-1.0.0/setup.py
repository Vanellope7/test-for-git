import setuptools

setuptools.setup(
    name="my-test", # 包的名称
    version="1.0.0", # 版本号
    packages=setuptools.find_packages(), # 自动寻找根目录下所有可以打包的package
)
